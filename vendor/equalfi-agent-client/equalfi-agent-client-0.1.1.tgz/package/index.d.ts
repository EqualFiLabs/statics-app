export type Mode = "proposal" | "manual" | "delegated";
export type StakeInput = {
    kind: "statics.stake-existing";
    version: 1;
    deploymentId: string;
    wallet: string;
    positionId: string;
    amount: string;
    maxFeePerTransaction: string;
};
export type Transaction = {
    chainId: number;
    to: string;
    data: string;
    value: string;
    gas: string;
    maxFeePerGas: string;
    maxPriorityFeePerGas: string;
};
export type Workflow = {
    id: string;
    identity: {
        appId: string;
        wallet: string;
    };
    mode: Mode;
    status: string;
    reason?: string;
    version: number;
    cancelRequested: boolean;
    plan: {
        digest: string;
        deploymentId: string;
        chainId: number;
        input: StakeInput;
        expiresAt: number;
        steps: {
            id: string;
            kind: "approval" | "stake";
            transaction: Transaction;
            principal: string;
            maxFee: string;
        }[];
    };
    attempts: {
        stepId: string;
        status: string;
        nonce: number;
        transaction?: Transaction;
        hash?: string;
        blockNumber?: string;
        result?: Record<string, string>;
    }[];
};
export type Policy = {
    wallet: string;
    chainId: number;
    paused: boolean;
    dailyPrincipal: string;
    dailyFees: string;
};
export type Grant = {
    wallet: string;
    chainId: number;
    deploymentId: string;
    positions: string[];
    exactApprovals: boolean;
    maxPrincipalPerAction: string;
    dailyPrincipal: string;
    dailyFees: string;
    expiresAt: number;
};
export type Message = {
    id: string;
    status: string;
    body: {
        text: string;
        assistant?: string;
        actionIds: string[];
        sources?: unknown[];
    };
};
export type SignRequest = Transaction & {
    nonce: number;
};
export declare class AgentClient {
    readonly options: {
        baseUrl: string;
        wallet: string;
        chainId: number;
        getAccessToken: () => Promise<string | null>;
        fetch?: typeof fetch;
    };
    constructor(options: {
        baseUrl: string;
        wallet: string;
        chainId: number;
        getAccessToken: () => Promise<string | null>;
        fetch?: typeof fetch;
    });
    request<T>(method: string, path: string, body?: unknown, signal?: AbortSignal): Promise<T>;
    capabilities(): Promise<{
        signer: {
            signerId: string;
            policyId: string;
            installed: boolean;
        } | null;
    }>;
    prepare(intentKey: string, input: StakeInput, mode?: Mode): Promise<Workflow>;
    execute(action: Workflow, mode: "manual" | "delegated"): Promise<Workflow>;
    status(id: string): Promise<Workflow>;
    activity(): Promise<Workflow[]>;
    cancel(id: string): Promise<Workflow>;
    reprepare(id: string): Promise<Workflow>;
    signature(id: string, raw: string): Promise<Workflow>;
    policy(): Promise<{
        global?: {
            body: Policy;
        };
        grant?: {
            body: Grant & {
                active: boolean;
            };
        };
    }>;
    setGlobal(policy: Policy): Promise<unknown>;
    setGrant(grant: Grant): Promise<unknown>;
    revoke(): Promise<unknown>;
    events(after: number, signal?: AbortSignal): Promise<{
        sequence: string;
        body: Workflow;
    }[]>;
    conversation(): Promise<{
        id: string;
    }>;
    messages(id: string): Promise<Message[]>;
    chat(id: string, intentKey: string, text: string): Promise<Message>;
    signNext(action: Workflow, sign: (request: SignRequest) => Promise<string>): Promise<Workflow>;
}
