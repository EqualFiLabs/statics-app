export class AgentClient {
    options;
    constructor(options) {
        this.options = options;
    }
    async request(method, path, body, signal) {
        const token = await this.options.getAccessToken();
        if (!token)
            throw new Error("Sign in to use the agent.");
        const response = await (this.options.fetch ?? fetch)(`${this.options.baseUrl}${path}`, {
            method,
            cache: "no-store",
            headers: {
                authorization: `Bearer ${token}`,
                "content-type": "application/json",
                "x-agent-wallet": this.options.wallet,
                "x-agent-chain": String(this.options.chainId),
            },
            body: body === undefined ? undefined : JSON.stringify(body),
            signal,
        });
        const data = await response.json();
        if (!response.ok)
            throw new Error(typeof data.error === "string" ? data.error : "Agent request failed.");
        return data;
    }
    capabilities() {
        return this.request("GET", "/v1/capabilities");
    }
    prepare(intentKey, input, mode = "proposal") {
        return this.request("POST", "/v1/actions", {
            intentKey,
            input,
            mode,
        });
    }
    execute(action, mode) {
        return this.request("POST", `/v1/actions/${action.id}/execute`, {
            planDigest: action.plan.digest,
            mode,
        });
    }
    status(id) {
        return this.request("GET", `/v1/actions/${id}`);
    }
    activity() {
        return this.request("GET", "/v1/actions");
    }
    cancel(id) {
        return this.request("POST", `/v1/actions/${id}/cancel`, {});
    }
    reprepare(id) {
        return this.request("POST", `/v1/actions/${id}/reprepare`, {});
    }
    signature(id, raw) {
        return this.request("POST", `/v1/actions/${id}/signature`, {
            raw,
        });
    }
    policy() {
        return this.request("GET", "/v1/policy");
    }
    setGlobal(policy) {
        return this.request("PUT", "/v1/policy/global", policy);
    }
    setGrant(grant) {
        return this.request("PUT", "/v1/grants", grant);
    }
    revoke() {
        return this.request("POST", "/v1/grants/revoke", {
            chainId: this.options.chainId,
        });
    }
    events(after, signal) {
        return this.request("GET", `/v1/events?after=${after}`, undefined, signal);
    }
    conversation() {
        return this.request("POST", "/v1/conversations", {});
    }
    messages(id) {
        return this.request("GET", `/v1/conversations/${id}`);
    }
    chat(id, intentKey, text) {
        return this.request("POST", `/v1/conversations/${id}/messages`, {
            intentKey,
            text,
        });
    }
    async signNext(action, sign) {
        const current = await this.status(action.id);
        if (current.status !== "awaiting_manual")
            throw new Error("The action is not ready for a wallet signature.");
        const attempt = current.attempts.find((a) => a.status === "reserved");
        if (!attempt?.transaction)
            throw new Error("No prepared transaction is available.");
        const raw = await sign({ ...attempt.transaction, nonce: attempt.nonce });
        return this.signature(current.id, raw);
    }
}
